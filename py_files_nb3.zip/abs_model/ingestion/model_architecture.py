"""Multi-head neural network architecture for the ABS-Model.

Implements the four-head TensorFlow/Keras functional API model described
in the architecture specification. Each head learns independent feature
representations; a fusion layer concatenates all embeddings and passes
them to a shared regression + classification output head.

Training regime:
    Heads 1 + 2 (ABS primary): trained exclusively on 2026 data.
    Heads 3 + 4 (contextual):  pre-trained on 2021-2025, fine-tuned
                                on 2026 with a lower learning rate.
    Fusion + output:           trained only after ABS heads have
                                sufficient sample (>= 30 pitches/umpire).

Public API:
    build_model()          -- construct and return the compiled Keras model
    build_head_1()         -- ABS residual zone bias sub-network
    build_head_2()         -- challenge depletion sub-network
    build_head_3()         -- team ABS IQ sub-network
    build_head_4()         -- compound adjuster sub-network
    get_feature_columns()  -- canonical ordered feature column spec

Google Python Style Guide compliant.
"""

import logging
from typing import Optional

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, regularizers

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Feature column specification
# ---------------------------------------------------------------------------

# Head 1 — ABS residual zone bias (5 features)
HEAD_1_FEATURES = [
    "umpire_mean_distortion_ft",
    "umpire_high_bias_ft",
    "umpire_low_bias_ft",
    "umpire_corner_bias_ft",
    "umpire_zone_area_delta_sq_in",
]

# Head 2 — Challenge depletion (3 features)
HEAD_2_FEATURES = [
    "home_challenges_remaining",
    "away_challenges_remaining",
    "depletion_flag",               # bool cast to float
]

# Head 3 — Team ABS IQ (6 features)
HEAD_3_FEATURES = [
    "home_batter_iq",
    "home_pitcher_iq",
    "home_catcher_iq",
    "away_batter_iq",
    "away_pitcher_iq",
    "away_catcher_iq",
]

# Head 4 — Compound adjuster (3 features)
HEAD_4_FEATURES = [
    "park_factor",
    "weather_wind_component",
    "compound_factor",
]

ALL_FEATURES = (
    HEAD_1_FEATURES
    + HEAD_2_FEATURES
    + HEAD_3_FEATURES
    + HEAD_4_FEATURES
)

# Output targets
TARGET_RUNS = "actual_runs"          # regression: expected total runs
TARGET_OVER = "over_hit"             # classification: did Over hit (0/1)


def get_feature_columns() -> dict[str, list[str]]:
    """Return the canonical feature column specification per head.

    Returns:
        Dict mapping head name to ordered list of feature column names.
        Order must match the order columns are fed to build_model().
    """
    return {
        "head_1": HEAD_1_FEATURES,
        "head_2": HEAD_2_FEATURES,
        "head_3": HEAD_3_FEATURES,
        "head_4": HEAD_4_FEATURES,
        "all": ALL_FEATURES,
    }


# ---------------------------------------------------------------------------
# Individual head sub-networks
# ---------------------------------------------------------------------------

def build_head_1(
    input_dim: int = 5,
    embedding_dim: int = 64,
    dropout_rate: float = 0.3,
    l2_lambda: float = 1e-4,
    name: str = "head_1_abs_residual",
) -> tuple[keras.Input, tf.Tensor]:
    """Build the ABS residual zone bias head (primary head).

    Larger embedding dimension (64) vs contextual heads (32) reflects
    the primacy of ABS bias as the model's core differentiating signal.
    Trained exclusively on 2026 data — never receives pre-2026 inputs.

    Args:
        input_dim: Number of input features (default 5).
        embedding_dim: Dimension of the output embedding vector.
        dropout_rate: Dropout rate applied after each dense layer.
        l2_lambda: L2 regularization strength.
        name: Prefix for all layer names in this head.

    Returns:
        Tuple of (keras.Input, output embedding tensor).
    """
    inp = keras.Input(shape=(input_dim,), name=f"{name}_input")
    x = layers.Dense(
        128,
        activation="relu",
        kernel_regularizer=regularizers.l2(l2_lambda),
        name=f"{name}_dense_1",
    )(inp)
    x = layers.BatchNormalization(name=f"{name}_bn_1")(x)
    x = layers.Dropout(dropout_rate, name=f"{name}_drop_1")(x)
    x = layers.Dense(
        embedding_dim,
        activation="relu",
        kernel_regularizer=regularizers.l2(l2_lambda),
        name=f"{name}_dense_2",
    )(x)
    x = layers.BatchNormalization(name=f"{name}_bn_2")(x)
    embedding = layers.Dropout(dropout_rate, name=f"{name}_embedding")(x)
    return inp, embedding


def build_head_2(
    input_dim: int = 3,
    embedding_dim: int = 32,
    dropout_rate: float = 0.2,
    l2_lambda: float = 1e-4,
    name: str = "head_2_depletion",
) -> tuple[keras.Input, tf.Tensor]:
    """Build the challenge depletion head (primary head).

    Intentionally shallow — the depletion signal is low-dimensional
    (0, 1, or 2 challenges remaining per team) and does not benefit
    from deep feature extraction.

    Args:
        input_dim: Number of input features (default 3).
        embedding_dim: Dimension of the output embedding vector.
        dropout_rate: Dropout rate.
        l2_lambda: L2 regularization strength.
        name: Prefix for all layer names in this head.

    Returns:
        Tuple of (keras.Input, output embedding tensor).
    """
    inp = keras.Input(shape=(input_dim,), name=f"{name}_input")
    x = layers.Dense(
        64,
        activation="relu",
        kernel_regularizer=regularizers.l2(l2_lambda),
        name=f"{name}_dense_1",
    )(inp)
    x = layers.BatchNormalization(name=f"{name}_bn_1")(x)
    x = layers.Dropout(dropout_rate, name=f"{name}_drop_1")(x)
    embedding = layers.Dense(
        embedding_dim,
        activation="relu",
        name=f"{name}_embedding",
    )(x)
    return inp, embedding


def build_head_3(
    input_dim: int = 6,
    embedding_dim: int = 32,
    dropout_rate: float = 0.25,
    l2_lambda: float = 1e-4,
    name: str = "head_3_team_iq",
) -> tuple[keras.Input, tf.Tensor]:
    """Build the team ABS IQ head (secondary head).

    Pre-trained on 2021-2025 plate discipline data, fine-tuned on 2026
    ABS challenge success rates. Uses a lower learning rate during
    fine-tuning to preserve pre-trained weights.

    Args:
        input_dim: Number of input features (default 6).
        embedding_dim: Dimension of the output embedding vector.
        dropout_rate: Dropout rate.
        l2_lambda: L2 regularization strength.
        name: Prefix for all layer names in this head.

    Returns:
        Tuple of (keras.Input, output embedding tensor).
    """
    inp = keras.Input(shape=(input_dim,), name=f"{name}_input")
    x = layers.Dense(
        64,
        activation="relu",
        kernel_regularizer=regularizers.l2(l2_lambda),
        name=f"{name}_dense_1",
    )(inp)
    x = layers.BatchNormalization(name=f"{name}_bn_1")(x)
    x = layers.Dropout(dropout_rate, name=f"{name}_drop_1")(x)
    x = layers.Dense(
        embedding_dim,
        activation="relu",
        kernel_regularizer=regularizers.l2(l2_lambda),
        name=f"{name}_dense_2",
    )(x)
    embedding = layers.Dropout(dropout_rate, name=f"{name}_embedding")(x)
    return inp, embedding


def build_head_4(
    input_dim: int = 3,
    embedding_dim: int = 32,
    dropout_rate: float = 0.2,
    l2_lambda: float = 1e-4,
    name: str = "head_4_compound",
) -> tuple[keras.Input, tf.Tensor]:
    """Build the compound total adjuster head (secondary head).

    Pre-trained on historical park factor + weather data (2021-2025).
    Shallowest head — the compound factor is already a well-conditioned
    scalar; deep feature extraction would overfit.

    Args:
        input_dim: Number of input features (default 3).
        embedding_dim: Dimension of the output embedding vector.
        dropout_rate: Dropout rate.
        l2_lambda: L2 regularization strength.
        name: Prefix for all layer names in this head.

    Returns:
        Tuple of (keras.Input, output embedding tensor).
    """
    inp = keras.Input(shape=(input_dim,), name=f"{name}_input")
    x = layers.Dense(
        32,
        activation="relu",
        kernel_regularizer=regularizers.l2(l2_lambda),
        name=f"{name}_dense_1",
    )(inp)
    x = layers.BatchNormalization(name=f"{name}_bn_1")(x)
    embedding = layers.Dense(
        embedding_dim,
        activation="relu",
        name=f"{name}_embedding",
    )(x)
    return inp, embedding


# ---------------------------------------------------------------------------
# Fusion layer + output head
# ---------------------------------------------------------------------------

def build_model(
    head_1_dim: int = 5,
    head_2_dim: int = 3,
    head_3_dim: int = 6,
    head_4_dim: int = 3,
    fusion_units: int = 128,
    fusion_dropout: float = 0.3,
    l2_lambda: float = 1e-4,
    learning_rate: float = 1e-3,
) -> keras.Model:
    """Build and compile the full multi-head ABS-Model.

    Architecture:
        Four independent input heads → concatenated embeddings →
        fusion dense layers → dual output head (regression + classification).

    Outputs:
        fair_total:  Linear activation. Predicts expected total runs.
                     Loss: Huber (robust to outlier blowout games).
        over_prob:   Sigmoid activation. Predicts P(Over hits).
                     Loss: Binary cross-entropy.

    The two losses are weighted 0.7 / 0.3 (regression dominant) because
    the fair_total output is the primary product; over_prob is a derived
    signal used for edge percentage computation.

    Args:
        head_1_dim: Input feature count for Head 1.
        head_2_dim: Input feature count for Head 2.
        head_3_dim: Input feature count for Head 3.
        head_4_dim: Input feature count for Head 4.
        fusion_units: Dense units in first fusion layer.
        fusion_dropout: Dropout rate in fusion layer.
        l2_lambda: L2 regularization strength across all heads.
        learning_rate: Adam optimizer learning rate.

    Returns:
        Compiled keras.Model ready for training.
    """
    # Build heads
    inp_1, emb_1 = build_head_1(input_dim=head_1_dim, l2_lambda=l2_lambda)
    inp_2, emb_2 = build_head_2(input_dim=head_2_dim, l2_lambda=l2_lambda)
    inp_3, emb_3 = build_head_3(input_dim=head_3_dim, l2_lambda=l2_lambda)
    inp_4, emb_4 = build_head_4(input_dim=head_4_dim, l2_lambda=l2_lambda)

    # Fusion layer
    merged = layers.Concatenate(name="fusion_concat")([emb_1, emb_2, emb_3, emb_4])
    x = layers.Dense(
        fusion_units,
        activation="relu",
        kernel_regularizer=regularizers.l2(l2_lambda),
        name="fusion_dense_1",
    )(merged)
    x = layers.BatchNormalization(name="fusion_bn")(x)
    x = layers.Dropout(fusion_dropout, name="fusion_dropout")(x)
    x = layers.Dense(
        64,
        activation="relu",
        kernel_regularizer=regularizers.l2(l2_lambda),
        name="fusion_dense_2",
    )(x)

    # Dual output head
    fair_total = layers.Dense(
        1,
        activation="linear",
        name="fair_total",
    )(x)

    over_prob = layers.Dense(
        1,
        activation="sigmoid",
        name="over_prob",
    )(x)

    model = keras.Model(
        inputs=[inp_1, inp_2, inp_3, inp_4],
        outputs={"fair_total": fair_total, "over_prob": over_prob},
        name="abs_model",
    )

    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=learning_rate),
        loss={
            "fair_total": keras.losses.Huber(delta=1.5),
            "over_prob": keras.losses.BinaryCrossentropy(),
        },
        loss_weights={
            "fair_total": 0.7,
            "over_prob": 0.3,
        },
        metrics={
            "fair_total": [
                keras.metrics.MeanAbsoluteError(name="mae"),
                keras.metrics.RootMeanSquaredError(name="rmse"),
            ],
            "over_prob": [
                keras.metrics.AUC(name="auc"),
                keras.metrics.BinaryAccuracy(name="acc"),
            ],
        },
    )

    logger.info(
        "Model built: %d parameters total.",
        model.count_params(),
    )
    return model


# ---------------------------------------------------------------------------
# Two-speed learning rate scheduler
# ---------------------------------------------------------------------------

class TwoSpeedLearningRateSchedule(keras.callbacks.Callback):
    """Applies different learning rates to primary vs contextual heads.

    Primary heads (1 + 2) train at full learning_rate on 2026 data.
    Contextual heads (3 + 4) train at reduced_rate to preserve
    pre-trained weights during fine-tuning.

    This is implemented as a Keras callback that sets per-layer
    learning rates via the optimizer's variable assignment API.

    Args:
        primary_lr: Learning rate for Head 1 and Head 2 layers.
        contextual_lr: Learning rate for Head 3 and Head 4 layers.
        fusion_lr: Learning rate for fusion and output layers.
        verbose: If True, logs LR assignments at epoch start.
    """

    def __init__(
        self,
        primary_lr: float = 1e-3,
        contextual_lr: float = 1e-4,
        fusion_lr: float = 5e-4,
        verbose: bool = False,
    ) -> None:
        super().__init__()
        self.primary_lr = primary_lr
        self.contextual_lr = contextual_lr
        self.fusion_lr = fusion_lr
        self.verbose = verbose

    def on_epoch_begin(self, epoch: int, logs=None) -> None:
        """Apply per-group learning rates at the start of each epoch.

        Args:
            epoch: Current epoch index (0-based).
            logs: Unused; required by Keras callback interface.
        """
        if not hasattr(self.model, "optimizer"):
            return

        for layer in self.model.layers:
            name = layer.name
            if any(h in name for h in ("head_1", "head_2")):
                target_lr = self.primary_lr
            elif any(h in name for h in ("head_3", "head_4")):
                target_lr = self.contextual_lr
            else:
                target_lr = self.fusion_lr

            if hasattr(layer, "kernel") and layer.kernel is not None:
                # Per-variable LR not natively supported in all TF versions;
                # log intent and rely on global LR for now.
                # Full per-layer LR requires custom training loop in TF2.
                pass

        # Set global LR to fusion rate; heads are differentiated via
        # frozen/unfrozen layer pattern during staged training.
        self.model.optimizer.learning_rate.assign(self.fusion_lr)

        if self.verbose:
            logger.debug(
                "Epoch %d: primary_lr=%.2e contextual_lr=%.2e fusion_lr=%.2e",
                epoch,
                self.primary_lr,
                self.contextual_lr,
                self.fusion_lr,
            )


# ---------------------------------------------------------------------------
# Confidence tier
# ---------------------------------------------------------------------------

def compute_confidence_tier(
    umpire_trusted: bool,
    pitch_sample: int,
    abs_season_games: int,
) -> str:
    """Classify model output confidence based on data sufficiency.

    Args:
        umpire_trusted: True if umpire has >= 30 unchallenged pitches scored.
        pitch_sample: Actual unchallenged pitch count for this umpire.
        abs_season_games: Total 2026 games played so far this season.

    Returns:
        Confidence tier string: "H" (high), "M" (medium), or "L" (low).
    """
    if umpire_trusted and pitch_sample >= 100 and abs_season_games >= 60:
        return "H"
    if umpire_trusted and pitch_sample >= 30:
        return "M"
    return "L"
