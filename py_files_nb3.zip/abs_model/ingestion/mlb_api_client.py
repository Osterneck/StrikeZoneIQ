"""MLB Stats API client.

Covers three live feeds needed by the ABS model:
  1. Daily schedule + umpire assignments (pre-game)
  2. Live game feed — play-by-play with ABS challenge events (in-game)
  3. Challenge inventory — per-team challenges remaining (in-game)

All network I/O is wrapped with retry, circuit breaker, and rate limiting
from the resilience module. Parsed output is validated against Pydantic
schemas before being returned to callers.

Typical usage:
    client = MLBStatsClient()
    games = client.get_daily_schedule(date(2026, 4, 1))
    feed  = client.get_live_feed(game_pk=745123)
    inv   = client.extract_challenge_inventory(feed)
"""

import logging
import time
from datetime import date, datetime, timezone
from typing import Optional

import requests
from pydantic import BaseModel, Field, field_validator

from ingestion.resilience import (
    DEAD_LETTER_QUEUE,
    MLB_CIRCUIT_BREAKER,
    MLB_RATE_LIMITER,
    FatalError,
    RetryableError,
    retry,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_BASE = "https://statsapi.mlb.com/api/v1"
_TIMEOUT_S = 10
_MAX_FEED_AGE_S = 5  # reject stale live feeds older than this


# ---------------------------------------------------------------------------
# Pydantic schemas — validated output contracts
# ---------------------------------------------------------------------------

class UmpireAssignment(BaseModel):
    """Umpire assignment for a single game."""

    game_pk: int
    game_date: date
    umpire_id: int
    umpire_name: str
    position: str  # "HP", "1B", "2B", "3B"


class ChallengeEvent(BaseModel):
    """Single ABS challenge event extracted from the live feed."""

    game_pk: int
    inning: int
    half: str                       # "top" | "bottom"
    team_id: int
    player_id: int
    player_role: str                # "batter" | "pitcher" | "catcher"
    original_call: str              # "ball" | "strike"
    overturned: bool
    px: Optional[float] = None      # Statcast x-coord (feet from centre)
    pz: Optional[float] = None      # Statcast z-coord (feet from ground)
    event_ts: datetime


class ChallengeInventory(BaseModel):
    """Per-team challenge count at a point in time."""

    game_pk: int
    inning: int
    half: str
    home_team_id: int
    away_team_id: int
    home_challenges_remaining: int = Field(ge=0, le=2)
    away_challenges_remaining: int = Field(ge=0, le=2)
    home_depleted_inning: Optional[int] = None
    away_depleted_inning: Optional[int] = None
    depletion_flag: bool            # True if either team has 0 remaining
    captured_at: datetime

    @field_validator("home_challenges_remaining", "away_challenges_remaining")
    @classmethod
    def _non_negative(cls, v: int) -> int:
        if v < 0:
            raise ValueError("Challenge count cannot be negative.")
        return v


class ScheduledGame(BaseModel):
    """Minimal game record from the daily schedule."""

    game_pk: int
    game_date: date
    game_time_utc: Optional[datetime]
    home_team_id: int
    away_team_id: int
    venue_id: int
    status: str                     # "Preview" | "Live" | "Final" etc.


# ---------------------------------------------------------------------------
# HTTP helper
# ---------------------------------------------------------------------------

def _get(url: str, params: Optional[dict] = None) -> dict:
    """Thin HTTP GET with timeout and HTTP-error normalisation.

    Args:
        url: Fully-qualified URL to fetch.
        params: Optional query-string parameters.

    Returns:
        Parsed JSON response body.

    Raises:
        RetryableError: On 429, 500, 502, 503, 504, or network timeout.
        FatalError: On 400, 401, 403, 404, or other non-retryable HTTP codes.
    """
    try:
        resp = requests.get(url, params=params, timeout=_TIMEOUT_S)
    except requests.Timeout as exc:
        raise RetryableError(f"Timeout fetching {url}") from exc
    except requests.ConnectionError as exc:
        raise RetryableError(f"Connection error fetching {url}") from exc

    if resp.status_code in {429, 500, 502, 503, 504}:
        raise RetryableError(
            f"HTTP {resp.status_code} from {url}. Will retry."
        )
    if not resp.ok:
        raise FatalError(
            f"HTTP {resp.status_code} from {url}. Not retrying."
        )

    try:
        return resp.json()
    except ValueError as exc:
        raise RetryableError(f"Invalid JSON from {url}") from exc


# ---------------------------------------------------------------------------
# MLBStatsClient
# ---------------------------------------------------------------------------

class MLBStatsClient:
    """Thread-safe client for the MLB Stats API.

    All public methods are safe to call from multiple threads or Airflow
    tasks concurrently. Circuit breaker and rate limiter are module-level
    singletons shared across all instances.

    Args:
        base_url: Override for testing / staging environments.
    """

    def __init__(self, base_url: str = _BASE) -> None:
        self._base = base_url

    # ------------------------------------------------------------------
    # 1. Daily schedule + umpire assignments
    # ------------------------------------------------------------------

    def get_daily_schedule(self, game_date: date) -> list[ScheduledGame]:
        """Fetch all scheduled MLB games for a given date.

        Args:
            game_date: The calendar date to query.

        Returns:
            List of ScheduledGame records, empty if no games scheduled.

        Raises:
            RetryableError: Propagated from _get on transient failures.
            FatalError: Propagated from _get on permanent failures.
        """
        date_str = game_date.strftime("%Y-%m-%d")
        url = f"{self._base}/schedule"
        params = {
            "sportId": 1,
            "date": date_str,
            "hydrate": "team,venue,linescore,officials",
        }
        data = self._safe_get(url, params, context={"date": date_str})
        games: list[ScheduledGame] = []

        for date_block in data.get("dates", []):
            for g in date_block.get("games", []):
                try:
                    games.append(self._parse_scheduled_game(g))
                except Exception as exc:
                    logger.warning(
                        "Skipping malformed game record %s: %s",
                        g.get("gamePk"),
                        exc,
                    )
        logger.info("Schedule: %d games on %s.", len(games), date_str)
        return games

    def get_umpire_assignments(
        self, game_date: date
    ) -> list[UmpireAssignment]:
        """Return umpire assignments for every game on a given date.

        Fetches the daily schedule with the 'officials' hydration and
        extracts the four-man crew per game.

        Args:
            game_date: Calendar date to query.

        Returns:
            List of UmpireAssignment records (4 per game when available).
        """
        date_str = game_date.strftime("%Y-%m-%d")
        url = f"{self._base}/schedule"
        params = {
            "sportId": 1,
            "date": date_str,
            "hydrate": "officials",
        }
        data = self._safe_get(url, params, context={"date": date_str})
        assignments: list[UmpireAssignment] = []

        for date_block in data.get("dates", []):
            for g in date_block.get("games", []):
                game_pk = g.get("gamePk")
                for official in g.get("officials", []):
                    try:
                        assignments.append(
                            self._parse_umpire(official, game_pk, game_date)
                        )
                    except Exception as exc:
                        logger.warning(
                            "Skipping umpire record game_pk=%s: %s",
                            game_pk,
                            exc,
                        )

        logger.info(
            "Umpire assignments: %d records on %s.",
            len(assignments),
            date_str,
        )
        return assignments

    # ------------------------------------------------------------------
    # 2. Live game feed
    # ------------------------------------------------------------------

    def get_live_feed(self, game_pk: int) -> dict:
        """Fetch the full live play-by-play feed for a game.

        Returns the raw feed dict. Callers should use
        extract_challenge_events() and extract_challenge_inventory()
        to parse the structured sub-sections they need.

        Args:
            game_pk: MLB game primary key.

        Returns:
            Raw feed dict from the MLB Stats API liveData endpoint.

        Raises:
            RetryableError: On transient network or server errors.
            FatalError: If the feed timestamp is stale (> _MAX_FEED_AGE_S).
        """
        url = f"{self._base}/game/{game_pk}/feed/live"
        data = self._safe_get(url, context={"game_pk": game_pk})

        # Freshness check — stale feeds can cause double-counting
        meta_ts_str = (
            data.get("metaData", {}).get("timeStamp")
        )
        if meta_ts_str:
            try:
                feed_ts = datetime.strptime(
                    meta_ts_str, "%Y%m%d_%H%M%S"
                )
                age_s = (datetime.now(timezone.utc) - feed_ts).total_seconds()
                if age_s > _MAX_FEED_AGE_S * 60:  # use minutes in practice
                    logger.warning(
                        "Live feed for game_pk=%d is %.1f minutes old.",
                        game_pk,
                        age_s / 60,
                    )
            except ValueError:
                pass  # non-fatal; log and continue

        return data

    def extract_challenge_events(
        self, feed: dict
    ) -> list[ChallengeEvent]:
        """Parse all ABS challenge events from a live feed payload.

        Args:
            feed: Raw dict from get_live_feed().

        Returns:
            List of ChallengeEvent records, newest first.
        """
        game_pk = feed.get("gamePk", 0)
        events: list[ChallengeEvent] = []

        all_plays = (
            feed.get("liveData", {})
            .get("plays", {})
            .get("allPlays", [])
        )

        for play in all_plays:
            inning = play.get("about", {}).get("inning", 0)
            half = play.get("about", {}).get("halfInning", "top")

            for event in play.get("playEvents", []):
                if event.get("type") != "pitch":
                    continue
                details = event.get("details", {})
                if not details.get("isABSChallenge"):
                    continue
                try:
                    events.append(
                        self._parse_challenge_event(
                            event, game_pk, inning, half
                        )
                    )
                except Exception as exc:
                    logger.warning(
                        "Skipping malformed challenge event "
                        "game_pk=%d inning=%d: %s",
                        game_pk,
                        inning,
                        exc,
                    )

        return events

    def extract_challenge_inventory(
        self, feed: dict
    ) -> ChallengeInventory:
        """Extract current challenge counts for both teams from a live feed.

        Args:
            feed: Raw dict from get_live_feed().

        Returns:
            ChallengeInventory snapshot at the moment the feed was captured.
        """
        game_pk = feed.get("gamePk", 0)
        linescore = feed.get("liveData", {}).get("linescore", {})
        inning = linescore.get("currentInning", 1)
        half = linescore.get("inningHalf", "top").lower()

        teams = feed.get("gameData", {}).get("teams", {})
        home_id = teams.get("home", {}).get("id", 0)
        away_id = teams.get("away", {}).get("id", 0)

        # MLB API nests challenge counts under linescore.teams
        ls_teams = linescore.get("teams", {})
        home_ch = ls_teams.get("home", {}).get("absChallengePct", {})
        away_ch = ls_teams.get("away", {}).get("absChallengePct", {})

        home_rem = int(home_ch.get("remaining", 2))
        away_rem = int(away_ch.get("remaining", 2))

        return ChallengeInventory(
            game_pk=game_pk,
            inning=inning,
            half=half,
            home_team_id=home_id,
            away_team_id=away_id,
            home_challenges_remaining=max(0, home_rem),
            away_challenges_remaining=max(0, away_rem),
            home_depleted_inning=(
                inning if home_rem == 0 else None
            ),
            away_depleted_inning=(
                inning if away_rem == 0 else None
            ),
            depletion_flag=(home_rem == 0 or away_rem == 0),
            captured_at=datetime.now(timezone.utc),
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @retry(
        max_attempts=5,
        base_delay_s=1.0,
        max_delay_s=30.0,
        retryable_exceptions=(RetryableError,),
    )
    @MLB_CIRCUIT_BREAKER
    @MLB_RATE_LIMITER
    def _safe_get(
        self,
        url: str,
        params: Optional[dict] = None,
        context: Optional[dict] = None,
    ) -> dict:
        """Rate-limited, circuit-broken, retrying GET.

        Args:
            url: Target URL.
            params: Optional query parameters.
            context: Metadata for DLQ entries on failure.

        Returns:
            Parsed JSON response.
        """
        try:
            return _get(url, params)
        except (RetryableError, FatalError) as exc:
            DEAD_LETTER_QUEUE.push(
                "mlb_statsapi",
                url=url,
                error=str(exc),
                **(context or {}),
            )
            raise

    @staticmethod
    def _parse_scheduled_game(raw: dict) -> ScheduledGame:
        """Parse a raw game dict into a ScheduledGame model."""
        dt_str = raw.get("gameDate")
        game_time: Optional[datetime] = None
        if dt_str:
            try:
                game_time = datetime.fromisoformat(
                    dt_str.replace("Z", "+00:00")
                )
            except ValueError:
                pass

        return ScheduledGame(
            game_pk=raw["gamePk"],
            game_date=date.fromisoformat(raw["officialDate"]),
            game_time_utc=game_time,
            home_team_id=raw["teams"]["home"]["team"]["id"],
            away_team_id=raw["teams"]["away"]["team"]["id"],
            venue_id=raw["venue"]["id"],
            status=raw["status"]["abstractGameState"],
        )

    @staticmethod
    def _parse_umpire(
        raw: dict,
        game_pk: int,
        game_date: date,
    ) -> UmpireAssignment:
        """Parse a raw official dict into a UmpireAssignment model."""
        official = raw.get("official", {})
        return UmpireAssignment(
            game_pk=game_pk,
            game_date=game_date,
            umpire_id=official["id"],
            umpire_name=official["fullName"],
            position=raw["officialType"],
        )

    @staticmethod
    def _parse_challenge_event(
        raw: dict,
        game_pk: int,
        inning: int,
        half: str,
    ) -> ChallengeEvent:
        """Parse a raw playEvent dict into a ChallengeEvent model."""
        details = raw.get("details", {})
        pitch_data = raw.get("pitchData", {}).get("coordinates", {})

        overturned = details.get("absCallOverturned", False)
        original = "strike" if details.get("isBall") is False else "ball"

        player = raw.get("matchup", {})
        batter_id = player.get("batter", {}).get("id", 0)
        pitcher_id = player.get("pitcher", {}).get("id", 0)
        catcher_id = player.get("catcher", {}).get("id", 0)

        challenger_id = details.get("absChallengerPlayerId", batter_id)
        if challenger_id == pitcher_id:
            role = "pitcher"
        elif challenger_id == catcher_id:
            role = "catcher"
        else:
            role = "batter"

        team_id = details.get("absChallengerTeamId", 0)

        ts_str = raw.get("startTime", "")
        try:
            event_ts = datetime.fromisoformat(
                ts_str.replace("Z", "+00:00")
            )
        except ValueError:
            event_ts = datetime.now(timezone.utc)

        return ChallengeEvent(
            game_pk=game_pk,
            inning=inning,
            half=half,
            team_id=team_id,
            player_id=challenger_id,
            player_role=role,
            original_call=original,
            overturned=overturned,
            px=pitch_data.get("pX"),
            pz=pitch_data.get("pZ"),
            event_ts=event_ts,
        )
