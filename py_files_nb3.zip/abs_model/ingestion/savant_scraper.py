"""Baseball Savant ABS batch scraper.

Pulls pitch-by-pitch Statcast data filtered to ABS-relevant fields via the
Baseball Savant CSV export endpoint. Runs once daily via Airflow at ~06:00 ET
after the previous day's games are processed.

Key design decisions:
  - Streams the CSV response to avoid loading multi-MB files into memory.
  - Validates every row against SavantPitchRow before writing to BigQuery.
  - Polite crawl: 3-second inter-request delay enforced by SAVANT_RATE_LIMITER.
  - Checksums the raw bytes before parsing to detect partial downloads.
  - Idempotent: a re-run for the same date is safe (BQ write is WRITE_TRUNCATE
    for the date partition, not WRITE_APPEND).

Typical usage:
    scraper = SavantABSScraper()
    rows = scraper.fetch_date(date(2026, 4, 1))
    print(f"Fetched {len(rows)} pitch rows.")
"""

import csv
import hashlib
import io
import logging
from datetime import date
from typing import Optional

import requests
from pydantic import BaseModel, Field, field_validator

from ingestion.resilience import (
    DEAD_LETTER_QUEUE,
    SAVANT_CIRCUIT_BREAKER,
    SAVANT_RATE_LIMITER,
    FatalError,
    RetryableError,
    retry,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_SAVANT_CSV_URL = (
    "https://baseballsavant.mlb.com/statcast_search/csv"
)
_TIMEOUT_S = 60          # large CSV; give it a full minute
_MAX_ROWS = 20_000       # sanity cap; alert if exceeded
_EXPECTED_MIN_ROWS = 1   # alert if fewer rows than this
_USER_AGENT = (
    "abs-model-research/1.0 "
    "(academic sports analytics; contact: research@absmodel.local)"
)

# Columns we actually need — Savant returns ~90; we select a strict subset
_REQUIRED_COLUMNS = frozenset({
    "game_pk",
    "game_date",
    "pitcher",
    "batter",
    "umpire",
    "inning",
    "inning_topbot",
    "plate_x",
    "plate_z",
    "description",
    "type",
    "sz_top",
    "sz_bot",
    "abs_challenge",        # 1 = challenged, 0 = not
    "abs_overturned",       # 1 = overturned, 0 = upheld / not challenged
    "abs_challenger_type",  # "batter" | "pitcher" | "catcher" | null
    "home_team",
    "away_team",
    "home_score",
    "away_score",
    "pitch_number",
    "at_bat_number",
    "events",
    "zone",
})


# ---------------------------------------------------------------------------
# Pydantic row schema
# ---------------------------------------------------------------------------

class SavantPitchRow(BaseModel):
    """One validated row from the Savant ABS CSV export."""

    game_pk: int
    game_date: date
    pitcher_id: int = Field(alias="pitcher")
    batter_id: int = Field(alias="batter")
    umpire_id: Optional[int] = Field(default=None, alias="umpire")
    inning: int
    inning_topbot: str                          # "Top" | "Bot"
    plate_x: Optional[float] = None            # horizontal coord (feet)
    plate_z: Optional[float] = None            # vertical coord (feet)
    description: str                            # raw Statcast event string
    pitch_type: str = Field(alias="type")      # "S" | "B" | "X"
    sz_top: Optional[float] = None             # batter's zone top (feet)
    sz_bot: Optional[float] = None             # batter's zone bottom (feet)
    abs_challenge: bool
    abs_overturned: bool
    abs_challenger_type: Optional[str] = None
    home_team: str
    away_team: str
    pitch_number: int
    at_bat_number: int

    model_config = {"populate_by_name": True}

    @field_validator("inning_topbot")
    @classmethod
    def _normalise_half(cls, v: str) -> str:
        normalised = v.strip().title()
        if normalised not in {"Top", "Bot"}:
            raise ValueError(f"Unexpected inning_topbot value: {v!r}")
        return normalised

    @field_validator("abs_challenger_type")
    @classmethod
    def _normalise_challenger_type(cls, v: Optional[str]) -> Optional[str]:
        if not v or v.strip().lower() in {"", "null", "none"}:
            return None
        v = v.strip().lower()
        if v not in {"batter", "pitcher", "catcher"}:
            raise ValueError(f"Unknown abs_challenger_type: {v!r}")
        return v


# ---------------------------------------------------------------------------
# SavantABSScraper
# ---------------------------------------------------------------------------

class SavantABSScraper:
    """Batch scraper for Baseball Savant ABS pitch data.

    Fetches the Statcast CSV export for a given date range, validates
    every row, and returns typed SavantPitchRow objects.

    Args:
        base_url: Override for testing.
        timeout_s: HTTP read timeout in seconds.
    """

    def __init__(
        self,
        base_url: str = _SAVANT_CSV_URL,
        timeout_s: int = _TIMEOUT_S,
    ) -> None:
        self._base_url = base_url
        self._timeout_s = timeout_s

    def fetch_date(self, target_date: date) -> list[SavantPitchRow]:
        """Fetch and validate all ABS pitch rows for a single calendar date.

        Intended to be called once daily by the Airflow DAG after games
        are confirmed final (typically 06:00 ET the following morning).

        Args:
            target_date: The game date to pull.

        Returns:
            List of validated SavantPitchRow records.

        Raises:
            RetryableError: On transient network failures (propagated up).
            FatalError: On checksum failure, empty payload, or schema breach.
        """
        date_str = target_date.strftime("%Y-%m-%d")
        logger.info("Savant ABS batch pull: %s", date_str)

        raw_bytes = self._download(date_str)
        self._verify_not_empty(raw_bytes, date_str)
        checksum = self._compute_checksum(raw_bytes)
        logger.debug("Savant payload checksum (%s): %s", date_str, checksum)

        rows = self._parse_csv(raw_bytes, date_str)
        self._sanity_check(rows, date_str)

        logger.info(
            "Savant ABS batch (%s): %d valid rows. checksum=%s",
            date_str,
            len(rows),
            checksum,
        )
        return rows

    def fetch_date_range(
        self,
        start: date,
        end: date,
    ) -> list[SavantPitchRow]:
        """Fetch ABS pitch rows for an inclusive date range.

        Pulls one date at a time to respect rate limits. Rate limiter
        is applied per-request inside _download().

        Args:
            start: First date (inclusive).
            end: Last date (inclusive).

        Returns:
            Combined list of all validated rows across the date range.
        """
        from datetime import timedelta

        all_rows: list[SavantPitchRow] = []
        current = start
        while current <= end:
            try:
                all_rows.extend(self.fetch_date(current))
            except FatalError as exc:
                logger.error(
                    "Fatal error on %s — skipping: %s", current, exc
                )
                DEAD_LETTER_QUEUE.push(
                    "baseball_savant",
                    date=str(current),
                    error=str(exc),
                )
            current += timedelta(days=1)
        return all_rows

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @retry(
        max_attempts=4,
        base_delay_s=3.0,
        max_delay_s=60.0,
        retryable_exceptions=(RetryableError,),
    )
    @SAVANT_CIRCUIT_BREAKER
    @SAVANT_RATE_LIMITER
    def _download(self, date_str: str) -> bytes:
        """Download raw CSV bytes for a single date.

        Args:
            date_str: Date in YYYY-MM-DD format.

        Returns:
            Raw CSV bytes.

        Raises:
            RetryableError: On 429, 5xx, timeout, or connection error.
            FatalError: On 4xx (excluding 429).
        """
        params = self._build_params(date_str, date_str)
        headers = {
            "User-Agent": _USER_AGENT,
            "Accept": "text/csv,application/octet-stream",
        }
        try:
            resp = requests.get(
                self._base_url,
                params=params,
                headers=headers,
                timeout=self._timeout_s,
                stream=True,
            )
        except requests.Timeout as exc:
            raise RetryableError(
                f"Savant download timed out for {date_str}"
            ) from exc
        except requests.ConnectionError as exc:
            raise RetryableError(
                f"Savant connection error for {date_str}"
            ) from exc

        if resp.status_code == 429:
            retry_after = int(resp.headers.get("Retry-After", 60))
            logger.warning(
                "Savant rate-limited. Waiting %ds.", retry_after
            )
            import time
            time.sleep(retry_after)
            raise RetryableError("Savant 429 — rate limited.")

        if resp.status_code in {500, 502, 503, 504}:
            raise RetryableError(
                f"Savant HTTP {resp.status_code} for {date_str}."
            )

        if not resp.ok:
            raise FatalError(
                f"Savant HTTP {resp.status_code} for {date_str}. "
                "Not retrying."
            )

        # Stream into memory chunk by chunk — avoids timeout on large files
        chunks: list[bytes] = []
        for chunk in resp.iter_content(chunk_size=65_536):
            if chunk:
                chunks.append(chunk)
        return b"".join(chunks)

    def _parse_csv(
        self,
        raw_bytes: bytes,
        date_str: str,
    ) -> list[SavantPitchRow]:
        """Parse and validate CSV bytes into SavantPitchRow records.

        Rows that fail Pydantic validation are logged and counted;
        if >10% of rows fail, a FatalError is raised.

        Args:
            raw_bytes: Raw CSV bytes from Savant.
            date_str: Human label used in log / error messages.

        Returns:
            List of valid SavantPitchRow objects.

        Raises:
            FatalError: If the CSV has missing required columns or >10%
                row validation failures.
        """
        text = raw_bytes.decode("utf-8", errors="replace")
        reader = csv.DictReader(io.StringIO(text))

        if not reader.fieldnames:
            raise FatalError(
                f"Savant CSV for {date_str} has no header row."
            )

        missing = _REQUIRED_COLUMNS - set(reader.fieldnames)
        if missing:
            raise FatalError(
                f"Savant CSV for {date_str} missing columns: {missing}"
            )

        rows: list[SavantPitchRow] = []
        errors = 0
        total = 0

        for raw_row in reader:
            total += 1
            cleaned = self._coerce_row(raw_row)
            try:
                rows.append(SavantPitchRow.model_validate(cleaned))
            except Exception as exc:
                errors += 1
                logger.debug(
                    "Row validation error (row %d, %s): %s",
                    total,
                    date_str,
                    exc,
                )

        if total > 0 and (errors / total) > 0.10:
            raise FatalError(
                f"Savant CSV for {date_str}: {errors}/{total} rows "
                f"({100*errors/total:.1f}%) failed validation. "
                "Aborting to avoid corrupt data."
            )

        if errors:
            logger.warning(
                "Savant CSV %s: %d/%d rows skipped (%.1f%%).",
                date_str,
                errors,
                total,
                100 * errors / total,
            )

        return rows

    @staticmethod
    def _coerce_row(raw: dict) -> dict:
        """Normalise raw CSV strings to Python types before validation.

        Args:
            raw: Dict of column → raw string value.

        Returns:
            Dict with numeric strings cast and nullish values set to None.
        """
        out: dict = {}
        for key, val in raw.items():
            if val in {"", "null", "None", "NA", "N/A"}:
                out[key] = None
            else:
                out[key] = val

        # Bool coercions
        for bool_col in ("abs_challenge", "abs_overturned"):
            v = out.get(bool_col)
            if v in {1, "1", "True", "true", "yes"}:
                out[bool_col] = True
            elif v in {0, "0", "False", "false", "no", None}:
                out[bool_col] = False

        return out

    @staticmethod
    def _build_params(start_str: str, end_str: str) -> dict:
        """Build Savant search query parameters.

        Args:
            start_str: Start date YYYY-MM-DD.
            end_str: End date YYYY-MM-DD.

        Returns:
            Dict of URL query parameters.
        """
        return {
            "hfSea": "2026|",
            "game_date_gt": start_str,
            "game_date_lt": end_str,
            "player_type": "pitcher",
            "hfFlag": "abs|",         # ABS challenge filter
            "type": "details",
            "min_pitches": "0",
            "min_results": "0",
            "group_by": "name",
            "sort_col": "pitches",
            "sort_order": "desc",
            "min_pas": "0",
        }

    @staticmethod
    def _verify_not_empty(raw_bytes: bytes, date_str: str) -> None:
        """Raise FatalError if the payload is suspiciously small.

        A valid Savant CSV always has a header row plus at least one data
        row (~200 bytes minimum). Anything smaller is a truncated response.

        Args:
            raw_bytes: Raw response bytes.
            date_str: Human label for error messages.

        Raises:
            FatalError: If payload is fewer than 200 bytes.
        """
        if len(raw_bytes) < 200:
            raise FatalError(
                f"Savant CSV for {date_str} is suspiciously small "
                f"({len(raw_bytes)} bytes). Likely a truncated or error "
                "response."
            )

    @staticmethod
    def _compute_checksum(raw_bytes: bytes) -> str:
        """Compute SHA-256 hex digest of raw bytes for audit logging.

        Args:
            raw_bytes: Bytes to hash.

        Returns:
            Lowercase hex-encoded SHA-256 digest.
        """
        return hashlib.sha256(raw_bytes).hexdigest()

    @staticmethod
    def _sanity_check(rows: list[SavantPitchRow], date_str: str) -> None:
        """Alert if row count is outside expected bounds.

        Does not raise — a day with no ABS challenges is valid data.
        Logs a warning so monitoring can catch unexpected gaps.

        Args:
            rows: Parsed rows.
            date_str: Human label.
        """
        if len(rows) > _MAX_ROWS:
            logger.warning(
                "Savant %s: unusually high row count %d (cap=%d). "
                "Verify no date-range bleed in params.",
                date_str,
                len(rows),
                _MAX_ROWS,
            )
        if len(rows) < _EXPECTED_MIN_ROWS:
            logger.warning(
                "Savant %s: only %d rows returned. "
                "Off-day or data pipeline delay?",
                date_str,
                len(rows),
            )
