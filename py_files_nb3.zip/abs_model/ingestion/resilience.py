"""Resilience primitives for all ingestion clients.

Provides retry logic, circuit breaker, and rate limiter decorators
used uniformly across every external API client in this package.
"""

import functools
import logging
import threading
import time
from collections import deque
from enum import Enum, auto
from typing import Callable, Optional, Type

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Retry with exponential backoff + jitter
# ---------------------------------------------------------------------------

class RetryableError(Exception):
    """Raised by clients to signal a transient failure worth retrying."""


class FatalError(Exception):
    """Raised by clients to signal a permanent failure; do not retry."""


def retry(
    max_attempts: int = 5,
    base_delay_s: float = 1.0,
    max_delay_s: float = 60.0,
    backoff_factor: float = 2.0,
    jitter: bool = True,
    retryable_exceptions: tuple[Type[Exception], ...] = (RetryableError,),
) -> Callable:
    """Decorator: retry with exponential backoff and optional full jitter.

    Args:
        max_attempts: Total attempts before re-raising the last exception.
        base_delay_s: Initial sleep duration in seconds.
        max_delay_s: Ceiling on sleep duration.
        backoff_factor: Multiplier applied each retry.
        jitter: If True, applies full jitter (sleep = random(0, cap)).
        retryable_exceptions: Exception types that trigger a retry.

    Returns:
        Decorator wrapping the target function with retry logic.

    Example:
        @retry(max_attempts=4, base_delay_s=2.0)
        def fetch() -> dict:
            ...
    """
    import random

    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            delay = base_delay_s
            last_exc: Optional[Exception] = None
            for attempt in range(1, max_attempts + 1):
                try:
                    return fn(*args, **kwargs)
                except FatalError:
                    raise
                except retryable_exceptions as exc:
                    last_exc = exc
                    if attempt == max_attempts:
                        break
                    cap = min(delay, max_delay_s)
                    sleep_for = random.uniform(0, cap) if jitter else cap
                    logger.warning(
                        "Attempt %d/%d failed for %s: %s. "
                        "Sleeping %.2fs before retry.",
                        attempt,
                        max_attempts,
                        fn.__qualname__,
                        exc,
                        sleep_for,
                    )
                    time.sleep(sleep_for)
                    delay = min(delay * backoff_factor, max_delay_s)
            logger.error(
                "All %d attempts exhausted for %s.",
                max_attempts,
                fn.__qualname__,
            )
            raise last_exc  # type: ignore[misc]

        return wrapper

    return decorator


# ---------------------------------------------------------------------------
# Circuit breaker
# ---------------------------------------------------------------------------

class CircuitState(Enum):
    CLOSED = auto()    # normal operation
    OPEN = auto()      # failing; reject calls immediately
    HALF_OPEN = auto() # probe: allow one call through


class CircuitBreaker:
    """Thread-safe circuit breaker protecting a downstream dependency.

    States:
        CLOSED  → track failures; trip to OPEN after threshold.
        OPEN    → fast-fail all calls; re-enter HALF_OPEN after recovery_s.
        HALF_OPEN → allow one probe; success → CLOSED, failure → OPEN.

    Args:
        name: Human-readable label used in log messages.
        failure_threshold: Consecutive failures required to open the circuit.
        recovery_s: Seconds to wait in OPEN before probing.
        success_threshold: Consecutive successes in HALF_OPEN to close.

    Example:
        cb = CircuitBreaker("mlb_api", failure_threshold=5, recovery_s=30)

        @cb
        def call_mlb() -> dict:
            ...
    """

    def __init__(
        self,
        name: str,
        failure_threshold: int = 5,
        recovery_s: float = 30.0,
        success_threshold: int = 2,
    ) -> None:
        self.name = name
        self.failure_threshold = failure_threshold
        self.recovery_s = recovery_s
        self.success_threshold = success_threshold

        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._opened_at: Optional[float] = None
        self._lock = threading.Lock()

    @property
    def state(self) -> CircuitState:
        """Current circuit state (thread-safe snapshot)."""
        with self._lock:
            self._maybe_transition_to_half_open()
            return self._state

    def __call__(self, fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            with self._lock:
                self._maybe_transition_to_half_open()
                if self._state == CircuitState.OPEN:
                    raise FatalError(
                        f"Circuit '{self.name}' is OPEN. "
                        f"Retry after {self.recovery_s}s."
                    )
            try:
                result = fn(*args, **kwargs)
                self._on_success()
                return result
            except Exception as exc:
                self._on_failure()
                raise exc

        return wrapper

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _maybe_transition_to_half_open(self) -> None:
        """Called under lock. Move OPEN → HALF_OPEN if recovery window passed."""
        if (
            self._state == CircuitState.OPEN
            and self._opened_at is not None
            and (time.monotonic() - self._opened_at) >= self.recovery_s
        ):
            logger.info("Circuit '%s': OPEN → HALF_OPEN (probe).", self.name)
            self._state = CircuitState.HALF_OPEN
            self._success_count = 0

    def _on_success(self) -> None:
        with self._lock:
            if self._state == CircuitState.HALF_OPEN:
                self._success_count += 1
                if self._success_count >= self.success_threshold:
                    logger.info(
                        "Circuit '%s': HALF_OPEN → CLOSED.", self.name
                    )
                    self._state = CircuitState.CLOSED
                    self._failure_count = 0
            elif self._state == CircuitState.CLOSED:
                self._failure_count = 0

    def _on_failure(self) -> None:
        with self._lock:
            self._failure_count += 1
            if self._state in (CircuitState.CLOSED, CircuitState.HALF_OPEN):
                if self._failure_count >= self.failure_threshold:
                    logger.error(
                        "Circuit '%s': tripping to OPEN after %d failures.",
                        self.name,
                        self._failure_count,
                    )
                    self._state = CircuitState.OPEN
                    self._opened_at = time.monotonic()


# ---------------------------------------------------------------------------
# Token-bucket rate limiter
# ---------------------------------------------------------------------------

class RateLimiter:
    """Thread-safe token-bucket rate limiter.

    Allows up to `rate` calls per `per_seconds` window. Excess calls
    block (sleep) until a token is available, rather than raising — this
    is intentional for polite scraping against public endpoints.

    Args:
        rate: Number of tokens (calls) allowed per window.
        per_seconds: Duration of the refill window in seconds.
        name: Label used in log messages.

    Example:
        limiter = RateLimiter(rate=1, per_seconds=3.0, name="savant")

        @limiter
        def scrape() -> bytes:
            ...
    """

    def __init__(
        self,
        rate: int,
        per_seconds: float,
        name: str = "default",
    ) -> None:
        self.rate = rate
        self.per_seconds = per_seconds
        self.name = name
        self._tokens = float(rate)
        self._last_refill = time.monotonic()
        self._lock = threading.Lock()

    def acquire(self) -> None:
        """Block until a token is available."""
        while True:
            with self._lock:
                now = time.monotonic()
                elapsed = now - self._last_refill
                refill = elapsed * (self.rate / self.per_seconds)
                self._tokens = min(float(self.rate), self._tokens + refill)
                self._last_refill = now
                if self._tokens >= 1.0:
                    self._tokens -= 1.0
                    return
                wait = (1.0 - self._tokens) / (self.rate / self.per_seconds)
            logger.debug(
                "RateLimiter '%s': throttling %.3fs.", self.name, wait
            )
            time.sleep(wait)

    def __call__(self, fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            self.acquire()
            return fn(*args, **kwargs)

        return wrapper


# ---------------------------------------------------------------------------
# Checksum validator
# ---------------------------------------------------------------------------

def validate_payload_checksum(
    payload: bytes,
    expected_checksum: str,
    algorithm: str = "sha256",
) -> None:
    """Validate payload integrity against an expected hex digest.

    Args:
        payload: Raw bytes to verify.
        expected_checksum: Hex-encoded digest to compare against.
        algorithm: Hash algorithm name (default 'sha256').

    Raises:
        FatalError: If the computed digest does not match expected.
    """
    import hashlib

    digest = hashlib.new(algorithm, payload).hexdigest()
    if digest != expected_checksum:
        raise FatalError(
            f"Checksum mismatch: expected {expected_checksum}, "
            f"got {digest}. Payload may be corrupt."
        )


# ---------------------------------------------------------------------------
# Dead-letter queue (in-memory; swap for Pub/Sub in production)
# ---------------------------------------------------------------------------

class DeadLetterQueue:
    """Holds failed fetch records for inspection and replay.

    Args:
        maxlen: Maximum number of entries retained (oldest evicted first).

    Example:
        dlq = DeadLetterQueue()
        dlq.push("mlb_api", game_pk=745123, error="timeout")
        for entry in dlq:
            print(entry)
    """

    def __init__(self, maxlen: int = 1_000) -> None:
        self._queue: deque[dict] = deque(maxlen=maxlen)
        self._lock = threading.Lock()

    def push(self, source: str, **context) -> None:
        """Record a failed fetch event.

        Args:
            source: Name of the data source that failed.
            **context: Arbitrary key-value metadata (e.g. game_pk, error).
        """
        entry = {
            "source": source,
            "ts": time.time(),
            **context,
        }
        with self._lock:
            self._queue.append(entry)
        logger.error("DLQ ← %s | %s", source, context)

    def drain(self) -> list[dict]:
        """Return and clear all DLQ entries."""
        with self._lock:
            entries = list(self._queue)
            self._queue.clear()
        return entries

    def __len__(self) -> int:
        with self._lock:
            return len(self._queue)

    def __iter__(self):
        with self._lock:
            snapshot = list(self._queue)
        return iter(snapshot)


# ---------------------------------------------------------------------------
# Module-level singletons (override in tests via dependency injection)
# ---------------------------------------------------------------------------

MLB_CIRCUIT_BREAKER = CircuitBreaker(
    "mlb_statsapi",
    failure_threshold=5,
    recovery_s=30.0,
)

SAVANT_CIRCUIT_BREAKER = CircuitBreaker(
    "baseball_savant",
    failure_threshold=3,
    recovery_s=60.0,
)

WEATHER_CIRCUIT_BREAKER = CircuitBreaker(
    "openweathermap",
    failure_threshold=5,
    recovery_s=20.0,
)

SAVANT_RATE_LIMITER = RateLimiter(
    rate=1,
    per_seconds=3.0,
    name="savant",
)

MLB_RATE_LIMITER = RateLimiter(
    rate=1,
    per_seconds=1.0,
    name="mlb_statsapi",
)

DEAD_LETTER_QUEUE = DeadLetterQueue(maxlen=5_000)
