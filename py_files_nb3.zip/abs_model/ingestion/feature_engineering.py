"""Feature engineering for the ABS-Model ingestion pipeline.

Transforms raw validated records from the ingestion layer into the
feature vectors consumed by each of the four model heads. All
computations are stateless pure functions or thin stateful accumulators
that can be unit-tested independently.

Public API:
    compute_zone_distortion()   -- Head 1: per-pitch residual bias scalar
    rolling_umpire_bias()       -- Head 1: per-umpire season bias profile
    compute_team_abs_iq()       -- Head 3: per-team/player IQ rates
    compound_total_adjuster()   -- Head 4: umpire × park × weather scalar
    build_feature_row()         -- fuses all heads into one feature dict

Google Python Style Guide compliant.
"""

import logging
import math
from datetime import date
from typing import Optional

import numpy as np
import pandas as pd
from pydantic import BaseModel, Field

from ingestion.mlb_api_client import (
    ChallengeEvent,
    ChallengeInventory,
    UmpireAssignment,
)
from ingestion.savant_scraper import SavantPitchRow
from ingestion.weather_client import WeatherSnapshot

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# ABS zone boundaries (2026 spec, Baseball Savant)
_ABS_ZONE_WIDTH_FT: float = 17.0 / 12.0       # 17 inches → feet
_ABS_ZONE_TOP_PCT: float = 0.535               # 53.5% of batter height
_ABS_ZONE_BOT_PCT: float = 0.270               # 27.0% of batter height
_PLATE_HALF_WIDTH_FT: float = _ABS_ZONE_WIDTH_FT / 2.0

# Park run factors (2023–2025 FanGraphs 3-year average, neutral = 100)
PARK_RUN_FACTORS: dict[int, float] = {
    31:    1.162,   # Coors Field
    2889:  1.051,   # Busch Stadium
    17:    1.048,   # Wrigley Field
    3289:  1.031,   # Citi Field
    3309:  1.028,   # Nationals Park
    2602:  1.021,   # Great American Ball Park
    3313:  1.019,   # Yankee Stadium
    3:     1.014,   # Fenway Park
    4705:  1.012,   # Truist Park
    2681:  1.009,   # Citizens Bank Park
    7:     0.998,   # Kauffman Stadium
    2394:  0.994,   # Comerica Park
    5:     0.992,   # Progressive Field
    18:    0.988,   # Guaranteed Rate Field
    32:    0.981,   # American Family Field
    3312:  0.978,   # Target Field
    22:    0.975,   # Dodger Stadium
    2395:  0.961,   # Oracle Park
    2680:  0.942,   # Petco Park
    680:   0.938,   # T-Mobile Park
    15:    0.931,   # Chase Field (retractable)
    2392:  0.929,   # Minute Maid Park (retractable)
    14:    0.921,   # Rogers Centre (dome)
    12:    0.918,   # Tropicana Field (dome)
    4169:  0.912,   # loanDepot park (dome)
    10:    0.959,   # Oakland Coliseum
    2:     1.003,   # Camden Yards
    5325:  1.007,   # Globe Life Field
}

_NEUTRAL_PARK_FACTOR: float = 1.000
_MIN_PITCH_SAMPLE: int = 30   # minimum pitches before bias score is trusted
_MIN_CHALLENGE_SAMPLE: int = 5  # minimum challenges for IQ score


# ---------------------------------------------------------------------------
# Pydantic output schemas
# ---------------------------------------------------------------------------

class ZoneDistortionScore(BaseModel):
    """Per-pitch zone distortion scalar for Head 1.

    Positive values indicate the umpire called a pitch a strike when ABS
    would have called it a ball (expanded zone). Negative values indicate
    the umpire called a ball when ABS would have called it a strike
    (compressed zone). Zero indicates an accurate call or a challenged
    pitch (already corrected by ABS).
    """

    pitch_id: str
    umpire_id: int
    game_pk: int
    inning: int
    distortion_ft: float        # signed distance from ABS boundary (feet)
    direction: str              # "expanded" | "compressed" | "accurate"
    challenged: bool
    overturned: bool


class UmpireBiasProfile(BaseModel):
    """Rolling per-umpire bias profile for Head 1 training.

    Aggregates unchallenged pitch distortions into a season-level
    profile. Only pitches NOT challenged (and therefore not corrected
    by ABS) contribute to this score — challenged pitches are already
    handled by the ABS system and do not represent surviving bias.
    """

    umpire_id: int
    season: int
    pitch_sample: int                   # unchallenged pitches scored
    mean_distortion_ft: float           # signed mean (+ = expanded)
    high_bias_ft: float                 # distortion at top of zone
    low_bias_ft: float                  # distortion at bottom of zone
    corner_bias_ft: float               # distortion at horizontal edges
    zone_area_delta_sq_in: float        # effective zone size vs. ABS spec
    trusted: bool                       # True if sample >= _MIN_PITCH_SAMPLE


class TeamABSIQ(BaseModel):
    """Per-team / per-role ABS challenge quality score for Head 3."""

    team_id: int
    season: int
    role: str                           # "batter" | "pitcher" | "catcher"
    challenges_made: int
    challenges_successful: int
    success_rate: float = Field(ge=0.0, le=1.0)
    trusted: bool                       # True if sample >= _MIN_CHALLENGE_SAMPLE


class CompoundTotalAdjustment(BaseModel):
    """Compound run-total adjustment scalar for Head 4.

    Multiplies umpire bias, park factor, and weather into a single
    expected-runs modifier applied to the league-average total.
    Values above 1.0 indicate elevated run environment; below 1.0
    indicate suppressed run environment.
    """

    game_pk: int
    umpire_id: int
    venue_id: int
    umpire_factor: float        # 1.0 + (mean_distortion / zone_height)
    park_factor: float          # from PARK_RUN_FACTORS
    weather_factor: float       # derived from wind_component
    compound_factor: float      # product of the three factors
    notes: str                  # human-readable explanation


class FeatureRow(BaseModel):
    """Fully fused feature vector for a single game — input to fusion layer."""

    game_pk: int
    game_date: date
    umpire_id: int
    venue_id: int

    # Head 1: ABS residual zone bias
    umpire_mean_distortion_ft: float
    umpire_high_bias_ft: float
    umpire_low_bias_ft: float
    umpire_corner_bias_ft: float
    umpire_zone_area_delta_sq_in: float
    umpire_trusted: bool

    # Head 2: challenge depletion (populated at inference time from live feed)
    home_challenges_remaining: int
    away_challenges_remaining: int
    depletion_flag: bool

    # Head 3: team ABS IQ
    home_batter_iq: float
    home_pitcher_iq: float
    home_catcher_iq: float
    away_batter_iq: float
    away_pitcher_iq: float
    away_catcher_iq: float

    # Head 4: compound adjuster
    park_factor: float
    weather_wind_component: float
    compound_factor: float

    # Ground truth (null until game is final)
    actual_runs: Optional[int] = None
    posted_total: Optional[float] = None


# ---------------------------------------------------------------------------
# Head 1 — Zone distortion functions
# ---------------------------------------------------------------------------

def compute_zone_distortion(row: SavantPitchRow) -> ZoneDistortionScore:
    """Compute the signed zone distortion scalar for a single pitch.

    For unchallenged pitches, distortion measures how far the umpire's
    call deviated from the ABS boundary. For challenged and overturned
    pitches, distortion is set to 0.0 — ABS already corrected the call.
    For challenged but upheld pitches, the umpire was correct so
    distortion is also 0.0.

    Args:
        row: A validated SavantPitchRow from the ingestion layer.

    Returns:
        ZoneDistortionScore with signed distortion in feet.

    Raises:
        ValueError: If pitch_type is not "S", "B", or "X".
    """
    if row.pitch_type not in {"S", "B", "X"}:
        raise ValueError(
            f"Unexpected pitch_type {row.pitch_type!r} for "
            f"game_pk={row.game_pk}."
        )

    # Challenged + overturned → ABS corrected it; no surviving distortion.
    # Challenged + upheld → umpire was right; no distortion.
    if row.abs_challenge:
        return ZoneDistortionScore(
            pitch_id=f"{row.game_pk}_{row.at_bat_number}_{row.pitch_number}",
            umpire_id=row.umpire_id or 0,
            game_pk=row.game_pk,
            inning=row.inning,
            distortion_ft=0.0,
            direction="accurate",
            challenged=True,
            overturned=row.abs_overturned,
        )

    # In-play or swinging strike → no ball/strike judgment made.
    if row.pitch_type == "X" or row.plate_x is None or row.plate_z is None:
        return ZoneDistortionScore(
            pitch_id=f"{row.game_pk}_{row.at_bat_number}_{row.pitch_number}",
            umpire_id=row.umpire_id or 0,
            game_pk=row.game_pk,
            inning=row.inning,
            distortion_ft=0.0,
            direction="accurate",
            challenged=False,
            overturned=False,
        )

    sz_top = row.sz_top or (row.plate_z + 1.5)   # fallback estimate
    sz_bot = row.sz_bot or (row.plate_z - 1.5)

    in_abs_zone = _pitch_in_abs_zone(row.plate_x, row.plate_z, sz_top, sz_bot)
    called_strike = row.pitch_type == "S"

    # Expanded zone: umpire called strike on a ball (outside ABS zone)
    if called_strike and not in_abs_zone:
        dist = _distance_outside_zone(row.plate_x, row.plate_z, sz_top, sz_bot)
        return ZoneDistortionScore(
            pitch_id=f"{row.game_pk}_{row.at_bat_number}_{row.pitch_number}",
            umpire_id=row.umpire_id or 0,
            game_pk=row.game_pk,
            inning=row.inning,
            distortion_ft=+dist,
            direction="expanded",
            challenged=False,
            overturned=False,
        )

    # Compressed zone: umpire called ball on a strike (inside ABS zone)
    if not called_strike and in_abs_zone:
        dist = _distance_inside_zone(row.plate_x, row.plate_z, sz_top, sz_bot)
        return ZoneDistortionScore(
            pitch_id=f"{row.game_pk}_{row.at_bat_number}_{row.pitch_number}",
            umpire_id=row.umpire_id or 0,
            game_pk=row.game_pk,
            inning=row.inning,
            distortion_ft=-dist,
            direction="compressed",
            challenged=False,
            overturned=False,
        )

    # Accurate call
    return ZoneDistortionScore(
        pitch_id=f"{row.game_pk}_{row.at_bat_number}_{row.pitch_number}",
        umpire_id=row.umpire_id or 0,
        game_pk=row.game_pk,
        inning=row.inning,
        distortion_ft=0.0,
        direction="accurate",
        challenged=False,
        overturned=False,
    )


def rolling_umpire_bias(
    distortion_scores: list[ZoneDistortionScore],
    umpire_id: int,
    season: int,
) -> UmpireBiasProfile:
    """Aggregate distortion scores into a rolling umpire bias profile.

    Only unchallenged pitches with non-zero distortion are included.
    Challenged pitches (corrected or upheld by ABS) are excluded because
    they do not represent surviving bias in the uncorrected zone.

    Args:
        distortion_scores: All ZoneDistortionScore records for this umpire.
        umpire_id: MLB umpire ID.
        season: Calendar year (e.g. 2026).

    Returns:
        UmpireBiasProfile with rolling bias metrics.
    """
    unchallenged = [
        s for s in distortion_scores
        if s.umpire_id == umpire_id and not s.challenged
    ]

    sample = len(unchallenged)
    if sample == 0:
        return UmpireBiasProfile(
            umpire_id=umpire_id,
            season=season,
            pitch_sample=0,
            mean_distortion_ft=0.0,
            high_bias_ft=0.0,
            low_bias_ft=0.0,
            corner_bias_ft=0.0,
            zone_area_delta_sq_in=0.0,
            trusted=False,
        )

    distortions = np.array([s.distortion_ft for s in unchallenged])
    mean_dist = float(np.mean(distortions))

    # Approximate zone area delta: mean_distortion applied uniformly
    # to perimeter → area change in square inches
    zone_height_in = (_ABS_ZONE_TOP_PCT - _ABS_ZONE_BOT_PCT) * (6.0 * 12.0)
    zone_width_in = 17.0
    dist_in = mean_dist * 12.0
    zone_area_delta = (
        (zone_width_in + dist_in) * (zone_height_in + dist_in)
        - zone_width_in * zone_height_in
    )

    # Directional sub-scores (simplified: use sign split of distortions)
    expanded = [s.distortion_ft for s in unchallenged if s.direction == "expanded"]
    compressed = [s.distortion_ft for s in unchallenged if s.direction == "compressed"]

    high_bias = float(np.mean(expanded)) if expanded else 0.0
    low_bias = float(np.mean(compressed)) if compressed else 0.0
    corner_bias = float(np.std(distortions)) if len(distortions) > 1 else 0.0

    return UmpireBiasProfile(
        umpire_id=umpire_id,
        season=season,
        pitch_sample=sample,
        mean_distortion_ft=round(mean_dist, 4),
        high_bias_ft=round(high_bias, 4),
        low_bias_ft=round(low_bias, 4),
        corner_bias_ft=round(corner_bias, 4),
        zone_area_delta_sq_in=round(zone_area_delta, 2),
        trusted=sample >= _MIN_PITCH_SAMPLE,
    )


# ---------------------------------------------------------------------------
# Head 3 — Team ABS IQ
# ---------------------------------------------------------------------------

def compute_team_abs_iq(
    events: list[ChallengeEvent],
    team_id: int,
    role: str,
    season: int,
) -> TeamABSIQ:
    """Compute ABS challenge quality (IQ) score for a team and role.

    Filters challenge events to the specified team and role, then
    computes the success rate over the season sample.

    Args:
        events: All ChallengeEvent records available for the season.
        team_id: MLB team ID.
        role: One of "batter", "pitcher", "catcher".
        season: Calendar year (used for record labeling only).

    Returns:
        TeamABSIQ with success rate and trust flag.

    Raises:
        ValueError: If role is not one of the three valid values.
    """
    valid_roles = {"batter", "pitcher", "catcher"}
    if role not in valid_roles:
        raise ValueError(
            f"Invalid role {role!r}. Must be one of {valid_roles}."
        )

    team_events = [
        e for e in events
        if e.team_id == team_id and e.player_role == role
    ]
    made = len(team_events)
    successful = sum(1 for e in team_events if e.overturned)
    rate = successful / made if made > 0 else 0.5  # prior: 50% when no data

    return TeamABSIQ(
        team_id=team_id,
        season=season,
        role=role,
        challenges_made=made,
        challenges_successful=successful,
        success_rate=round(rate, 4),
        trusted=made >= _MIN_CHALLENGE_SAMPLE,
    )


# ---------------------------------------------------------------------------
# Head 4 — Compound total adjuster
# ---------------------------------------------------------------------------

def compound_total_adjuster(
    bias_profile: UmpireBiasProfile,
    venue_id: int,
    weather_snapshot: Optional[WeatherSnapshot],
    game_pk: int,
) -> CompoundTotalAdjustment:
    """Compute the compound run-environment factor for Head 4.

    Multiplies three independent factors:
      - Umpire factor: derived from mean zone distortion vs. ABS zone height
      - Park factor: from the PARK_RUN_FACTORS table
      - Weather factor: derived from wind component scalar

    Args:
        bias_profile: Rolling UmpireBiasProfile for the HP umpire.
        venue_id: MLB Stats API venue ID.
        weather_snapshot: Most recent WeatherSnapshot; None for domes.
        game_pk: Game PK for the output record.

    Returns:
        CompoundTotalAdjustment with the product factor and component breakdown.
    """
    # -- Umpire factor --
    # Zone height varies by batter; use MLB average batter height 73 inches.
    avg_batter_height_in = 73.0
    abs_zone_height_in = (
        (_ABS_ZONE_TOP_PCT - _ABS_ZONE_BOT_PCT) * avg_batter_height_in
    )
    distortion_pct = (
        bias_profile.mean_distortion_ft * 12.0 / abs_zone_height_in
    )
    # Positive distortion (expanded zone) → more Ks → fewer runs → factor < 1
    # Negative distortion (compressed zone) → more walks → more runs → factor > 1
    umpire_factor = 1.0 - (distortion_pct * 0.5)

    # -- Park factor --
    park_factor = PARK_RUN_FACTORS.get(venue_id, _NEUTRAL_PARK_FACTOR)

    # -- Weather factor --
    # Each 10 mph of wind blowing out adds ~0.03 to run environment (empirical)
    if weather_snapshot is None or weather_snapshot.is_dome:
        weather_factor = 1.0
        wind_note = "dome or no snapshot — weather factor neutral"
    else:
        wc = weather_snapshot.wind_component
        weather_factor = 1.0 + (wc / 10.0) * 0.03
        wind_note = (
            f"wind {wc:+.1f} mph {'out' if wc > 0 else 'in'} "
            f"→ weather factor {weather_factor:.4f}"
        )

    compound = umpire_factor * park_factor * weather_factor

    notes = (
        f"umpire_factor={umpire_factor:.4f} "
        f"(distortion={bias_profile.mean_distortion_ft:+.4f} ft) | "
        f"park_factor={park_factor:.4f} (venue_id={venue_id}) | "
        f"{wind_note}"
    )

    return CompoundTotalAdjustment(
        game_pk=game_pk,
        umpire_id=bias_profile.umpire_id,
        venue_id=venue_id,
        umpire_factor=round(umpire_factor, 4),
        park_factor=round(park_factor, 4),
        weather_factor=round(weather_factor, 4),
        compound_factor=round(compound, 4),
        notes=notes,
    )


# ---------------------------------------------------------------------------
# Fusion — build_feature_row
# ---------------------------------------------------------------------------

def build_feature_row(
    game_pk: int,
    game_date: date,
    umpire_id: int,
    venue_id: int,
    bias_profile: UmpireBiasProfile,
    challenge_inventory: ChallengeInventory,
    home_team_iq: dict[str, TeamABSIQ],
    away_team_iq: dict[str, TeamABSIQ],
    compound_adjustment: CompoundTotalAdjustment,
    weather_snapshot: Optional[WeatherSnapshot] = None,
    actual_runs: Optional[int] = None,
    posted_total: Optional[float] = None,
) -> FeatureRow:
    """Fuse all head outputs into a single FeatureRow for the fusion layer.

    Args:
        game_pk: MLB game primary key.
        game_date: Calendar date of the game.
        umpire_id: MLB umpire ID for the HP umpire.
        venue_id: MLB venue ID.
        bias_profile: UmpireBiasProfile from rolling_umpire_bias().
        challenge_inventory: ChallengeInventory snapshot from the live feed.
        home_team_iq: Dict mapping role → TeamABSIQ for the home team.
            Expected keys: "batter", "pitcher", "catcher".
        away_team_iq: Dict mapping role → TeamABSIQ for the away team.
        compound_adjustment: CompoundTotalAdjustment from compound_total_adjuster().
        weather_snapshot: Optional WeatherSnapshot for additional context.
        actual_runs: Ground-truth total runs; None until game is final.
        posted_total: Sportsbook posted O/U line; None if not yet available.

    Returns:
        FeatureRow ready for consumption by the fusion layer.
    """
    def _iq_rate(iq_dict: dict[str, TeamABSIQ], role: str) -> float:
        """Return success_rate for a role, defaulting to 0.5."""
        iq = iq_dict.get(role)
        return iq.success_rate if iq is not None else 0.5

    wind_component = (
        weather_snapshot.wind_component
        if weather_snapshot is not None
        else 0.0
    )

    return FeatureRow(
        game_pk=game_pk,
        game_date=game_date,
        umpire_id=umpire_id,
        venue_id=venue_id,
        umpire_mean_distortion_ft=bias_profile.mean_distortion_ft,
        umpire_high_bias_ft=bias_profile.high_bias_ft,
        umpire_low_bias_ft=bias_profile.low_bias_ft,
        umpire_corner_bias_ft=bias_profile.corner_bias_ft,
        umpire_zone_area_delta_sq_in=bias_profile.zone_area_delta_sq_in,
        umpire_trusted=bias_profile.trusted,
        home_challenges_remaining=challenge_inventory.home_challenges_remaining,
        away_challenges_remaining=challenge_inventory.away_challenges_remaining,
        depletion_flag=challenge_inventory.depletion_flag,
        home_batter_iq=_iq_rate(home_team_iq, "batter"),
        home_pitcher_iq=_iq_rate(home_team_iq, "pitcher"),
        home_catcher_iq=_iq_rate(home_team_iq, "catcher"),
        away_batter_iq=_iq_rate(away_team_iq, "batter"),
        away_pitcher_iq=_iq_rate(away_team_iq, "pitcher"),
        away_catcher_iq=_iq_rate(away_team_iq, "catcher"),
        park_factor=compound_adjustment.park_factor,
        weather_wind_component=wind_component,
        compound_factor=compound_adjustment.compound_factor,
        actual_runs=actual_runs,
        posted_total=posted_total,
    )


# ---------------------------------------------------------------------------
# DataFrame helpers
# ---------------------------------------------------------------------------

def distortions_to_dataframe(
    scores: list[ZoneDistortionScore],
) -> pd.DataFrame:
    """Convert a list of ZoneDistortionScore records to a pandas DataFrame.

    Args:
        scores: List of ZoneDistortionScore objects.

    Returns:
        DataFrame with one row per pitch, typed columns.
    """
    return pd.DataFrame([s.model_dump() for s in scores])


def feature_rows_to_dataframe(
    rows: list[FeatureRow],
) -> pd.DataFrame:
    """Convert a list of FeatureRow records to a pandas DataFrame.

    Args:
        rows: List of FeatureRow objects.

    Returns:
        DataFrame with one row per game, typed columns.
    """
    return pd.DataFrame([r.model_dump() for r in rows])


# ---------------------------------------------------------------------------
# Internal geometry helpers (not part of public API)
# ---------------------------------------------------------------------------

def _pitch_in_abs_zone(
    plate_x: float,
    plate_z: float,
    sz_top: float,
    sz_bot: float,
) -> bool:
    """Return True if the pitch is inside the batter-specific ABS zone.

    Args:
        plate_x: Horizontal location in feet (0 = centre of plate).
        plate_z: Vertical location in feet from ground.
        sz_top: Top of batter's ABS zone in feet.
        sz_bot: Bottom of batter's ABS zone in feet.

    Returns:
        True if pitch is within the ABS strike zone.
    """
    return (
        abs(plate_x) <= _PLATE_HALF_WIDTH_FT
        and sz_bot <= plate_z <= sz_top
    )


def _distance_outside_zone(
    plate_x: float,
    plate_z: float,
    sz_top: float,
    sz_bot: float,
) -> float:
    """Compute distance a pitch is outside the ABS zone (feet).

    Used for expanded-zone distortion (umpire called strike on a ball).

    Args:
        plate_x: Horizontal pitch location in feet.
        plate_z: Vertical pitch location in feet.
        sz_top: Top of ABS zone in feet.
        sz_bot: Bottom of ABS zone in feet.

    Returns:
        Euclidean distance outside zone boundary in feet (always >= 0).
    """
    dx = max(0.0, abs(plate_x) - _PLATE_HALF_WIDTH_FT)
    dz = max(0.0, plate_z - sz_top) + max(0.0, sz_bot - plate_z)
    return math.sqrt(dx**2 + dz**2)


def _distance_inside_zone(
    plate_x: float,
    plate_z: float,
    sz_top: float,
    sz_bot: float,
) -> float:
    """Compute distance a pitch is inside the ABS zone (feet).

    Used for compressed-zone distortion (umpire called ball on a strike).

    Args:
        plate_x: Horizontal pitch location in feet.
        plate_z: Vertical pitch location in feet.
        sz_top: Top of ABS zone in feet.
        sz_bot: Bottom of ABS zone in feet.

    Returns:
        Distance to nearest ABS zone boundary in feet (always >= 0).
    """
    dx = max(0.0, _PLATE_HALF_WIDTH_FT - abs(plate_x))
    dz_top = sz_top - plate_z
    dz_bot = plate_z - sz_bot
    dz = min(dz_top, dz_bot)
    return max(0.0, min(dx, dz))
