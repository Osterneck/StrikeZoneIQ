"""Weather client for pre-game and live weather snapshots.

Captures three snapshots per game (T-60min, T-30min, T-0) from the
OpenWeatherMap API and computes a wind component vector (positive = out,
negative = in) relative to each ballpark's orientation.

Ballpark orientations are hardcoded from published surveys. Wind direction
is decomposed into a scalar 'wind_component' that directly maps to run
expectancy adjustment in the compound adjuster head.

Typical usage:
    client = WeatherClient(api_key="your_key")
    snap = client.capture_snapshot(game_pk=745123, venue_id=31)
    print(snap.wind_component)   # +8.2 = 8.2 mph blowing out
"""

import logging
import math
from datetime import datetime, timezone
from typing import Optional

import requests
from pydantic import BaseModel, Field, field_validator

from ingestion.resilience import (
    DEAD_LETTER_QUEUE,
    WEATHER_CIRCUIT_BREAKER,
    FatalError,
    RetryableError,
    retry,
)

logger = logging.getLogger(__name__)

_OWM_URL = "https://api.openweathermap.org/data/2.5/weather"
_TIMEOUT_S = 8

# ---------------------------------------------------------------------------
# Ballpark geo + orientation table
# venue_id  : MLB Stats API venue ID
# lat / lon : stadium coordinates
# home_plate_bearing_deg : compass direction FROM home plate TOWARD CF
#   (wind blowing FROM this direction is "blowing in"; opposite = "blowing out")
# ---------------------------------------------------------------------------

VENUE_META: dict[int, dict] = {
    # Coors Field
    31:  {"lat": 39.7559, "lon": -104.9942, "hp_bearing": 334},
    # Petco Park
    2680: {"lat": 32.7076, "lon": -117.1570, "hp_bearing": 305},
    # Wrigley Field
    17:  {"lat": 41.9484, "lon": -87.6553, "hp_bearing": 49},
    # Fenway Park
    3:   {"lat": 42.3467, "lon": -71.0972, "hp_bearing": 94},
    # Yankee Stadium
    3313: {"lat": 40.8296, "lon": -73.9262, "hp_bearing": 338},
    # Oracle Park
    2395: {"lat": 37.7786, "lon": -122.3893, "hp_bearing": 3},
    # Dodger Stadium
    22:  {"lat": 34.0739, "lon": -118.2400, "hp_bearing": 328},
    # Globe Life Field
    5325: {"lat": 32.7473, "lon": -97.0824, "hp_bearing": 330},
    # Truist Park
    4705: {"lat": 33.8908, "lon": -84.4678, "hp_bearing": 13},
    # Great American Ball Park
    2602: {"lat": 39.0975, "lon": -84.5064, "hp_bearing": 0},
    # Camden Yards
    2:   {"lat": 39.2839, "lon": -76.6216, "hp_bearing": 5},
    # Guaranteed Rate Field
    18:  {"lat": 41.8299, "lon": -87.6338, "hp_bearing": 4},
    # Progressive Field
    5:   {"lat": 41.4962, "lon": -81.6852, "hp_bearing": 2},
    # Comerica Park
    2394: {"lat": 42.3390, "lon": -83.0485, "hp_bearing": 355},
    # American Family Field
    32:  {"lat": 43.0280, "lon": -87.9712, "hp_bearing": 6},
    # Target Field
    3312: {"lat": 44.9817, "lon": -93.2778, "hp_bearing": 4},
    # Kauffman Stadium
    7:   {"lat": 39.0517, "lon": -94.4803, "hp_bearing": 11},
    # Tropicana Field (dome — wind component forced to 0)
    12:  {"lat": 27.7682, "lon": -82.6534, "hp_bearing": None},
    # loanDepot park (dome)
    4169: {"lat": 25.7781, "lon": -80.2196, "hp_bearing": None},
    # Minute Maid Park (retractable)
    2392: {"lat": 29.7573, "lon": -95.3555, "hp_bearing": None},
    # T-Mobile Park (retractable)
    680: {"lat": 47.5914, "lon": -122.3325, "hp_bearing": None},
    # Chase Field (retractable)
    15:  {"lat": 33.4453, "lon": -112.0667, "hp_bearing": None},
    # Rogers Centre (dome)
    14:  {"lat": 43.6414, "lon": -79.3894, "hp_bearing": None},
    # LoanDepot alternate ID
    4705: {"lat": 25.7781, "lon": -80.2196, "hp_bearing": None},
    # Nationals Park
    3309: {"lat": 38.8730, "lon": -77.0074, "hp_bearing": 356},
    # Citizens Bank Park
    2681: {"lat": 39.9061, "lon": -75.1665, "hp_bearing": 338},
    # Citi Field
    3289: {"lat": 40.7571, "lon": -73.8458, "hp_bearing": 3},
    # PNC Park
    31:  {"lat": 40.4469, "lon": -80.0057, "hp_bearing": 355},
    # Busch Stadium
    2889: {"lat": 38.6226, "lon": -90.1928, "hp_bearing": 349},
    # American Family Field alt
    32:  {"lat": 43.0280, "lon": -87.9712, "hp_bearing": 6},
    # Oakland Coliseum
    10:  {"lat": 37.7516, "lon": -122.2005, "hp_bearing": 320},
}


# ---------------------------------------------------------------------------
# Pydantic schema
# ---------------------------------------------------------------------------

class WeatherSnapshot(BaseModel):
    """Weather conditions at a specific pre-game checkpoint."""

    snapshot_id: Optional[str] = None          # set by caller (uuid)
    game_pk: int
    venue_id: int
    captured_at: datetime
    checkpoint: str                             # "T-60" | "T-30" | "T-0"
    temp_f: float
    humidity_pct: float = Field(ge=0, le=100)
    wind_speed_mph: float = Field(ge=0)
    wind_dir_deg: float = Field(ge=0, le=360)  # meteorological: FROM
    wind_component: float                       # + = blowing out, - = blowing in
    is_dome: bool

    @field_validator("wind_component")
    @classmethod
    def _component_only_for_open_air(
        cls, v: float, info
    ) -> float:
        if info.data.get("is_dome") and v != 0.0:
            raise ValueError(
                "wind_component must be 0.0 for dome venues."
            )
        return v


# ---------------------------------------------------------------------------
# WeatherClient
# ---------------------------------------------------------------------------

class WeatherClient:
    """Fetches weather snapshots for MLB venues via OpenWeatherMap.

    Args:
        api_key: OWM API key (loaded from Secret Manager in production).
        base_url: Override for testing.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = _OWM_URL,
    ) -> None:
        if not api_key:
            raise ValueError(
                "WeatherClient requires a non-empty api_key. "
                "Load from Secret Manager, never hardcode."
            )
        self._api_key = api_key
        self._base_url = base_url

    def capture_snapshot(
        self,
        game_pk: int,
        venue_id: int,
        checkpoint: str = "T-0",
    ) -> WeatherSnapshot:
        """Fetch current conditions for a venue and return a snapshot.

        Args:
            game_pk: MLB game primary key for the snapshot record.
            venue_id: MLB Stats API venue ID.
            checkpoint: Label for this snapshot ("T-60" | "T-30" | "T-0").

        Returns:
            Validated WeatherSnapshot.

        Raises:
            FatalError: If venue_id not in VENUE_META.
            RetryableError: On transient OWM failures.
        """
        meta = VENUE_META.get(venue_id)
        if meta is None:
            raise FatalError(
                f"venue_id {venue_id} not in VENUE_META. "
                "Add it before requesting a snapshot."
            )

        raw = self._fetch_owm(meta["lat"], meta["lon"])
        return self._build_snapshot(raw, game_pk, venue_id, meta, checkpoint)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @retry(
        max_attempts=4,
        base_delay_s=1.0,
        max_delay_s=20.0,
        retryable_exceptions=(RetryableError,),
    )
    @WEATHER_CIRCUIT_BREAKER
    def _fetch_owm(self, lat: float, lon: float) -> dict:
        """Call the OWM current-weather endpoint.

        Args:
            lat: Latitude.
            lon: Longitude.

        Returns:
            Parsed OWM JSON response.

        Raises:
            RetryableError: On 429, 5xx, or network errors.
            FatalError: On 4xx (excluding 429).
        """
        params = {
            "lat": lat,
            "lon": lon,
            "appid": self._api_key,
            "units": "imperial",
        }
        try:
            resp = requests.get(
                self._base_url, params=params, timeout=_TIMEOUT_S
            )
        except requests.Timeout as exc:
            raise RetryableError(
                f"OWM timeout at ({lat}, {lon})"
            ) from exc
        except requests.ConnectionError as exc:
            raise RetryableError(
                f"OWM connection error at ({lat}, {lon})"
            ) from exc

        if resp.status_code == 429:
            raise RetryableError("OWM 429 — rate limited.")
        if resp.status_code in {500, 502, 503, 504}:
            raise RetryableError(f"OWM HTTP {resp.status_code}.")
        if not resp.ok:
            DEAD_LETTER_QUEUE.push(
                "openweathermap",
                lat=lat,
                lon=lon,
                status=resp.status_code,
            )
            raise FatalError(f"OWM HTTP {resp.status_code}.")

        try:
            return resp.json()
        except ValueError as exc:
            raise RetryableError("OWM returned invalid JSON.") from exc

    def _build_snapshot(
        self,
        raw: dict,
        game_pk: int,
        venue_id: int,
        meta: dict,
        checkpoint: str,
    ) -> WeatherSnapshot:
        """Convert OWM response dict into a WeatherSnapshot.

        Args:
            raw: OWM current-weather JSON.
            game_pk: Game PK for the record.
            venue_id: Venue identifier.
            meta: Entry from VENUE_META.
            checkpoint: Snapshot label.

        Returns:
            Validated WeatherSnapshot.
        """
        is_dome = meta["hp_bearing"] is None
        wind_data = raw.get("wind", {})
        wind_speed_mph = float(wind_data.get("speed", 0.0))
        wind_dir_deg = float(wind_data.get("deg", 0.0))
        main = raw.get("main", {})
        temp_f = float(main.get("temp", 70.0))
        humidity_pct = float(main.get("humidity", 50.0))

        if is_dome:
            wind_component = 0.0
        else:
            wind_component = self._compute_wind_component(
                wind_speed_mph=wind_speed_mph,
                wind_dir_deg=wind_dir_deg,
                hp_bearing=meta["hp_bearing"],
            )

        return WeatherSnapshot(
            game_pk=game_pk,
            venue_id=venue_id,
            captured_at=datetime.now(timezone.utc),
            checkpoint=checkpoint,
            temp_f=temp_f,
            humidity_pct=humidity_pct,
            wind_speed_mph=wind_speed_mph,
            wind_dir_deg=wind_dir_deg,
            wind_component=round(wind_component, 2),
            is_dome=is_dome,
        )

    @staticmethod
    def _compute_wind_component(
        wind_speed_mph: float,
        wind_dir_deg: float,
        hp_bearing: int,
    ) -> float:
        """Decompose wind into outfield / infield scalar component.

        Positive result = wind blowing out toward CF (increases runs).
        Negative result = wind blowing in from CF (suppresses runs).
        Zero = crosswind (perpendicular to HP→CF axis).

        The meteorological convention is that wind_dir_deg is the direction
        the wind is coming FROM. A wind "from" 180° (south) at Wrigley
        (HP bearing ~49°) is blowing northward, which is roughly out.

        Args:
            wind_speed_mph: Wind speed in mph.
            wind_dir_deg: Meteorological wind direction (degrees FROM).
            hp_bearing: Compass direction from home plate toward CF.

        Returns:
            Signed wind component in mph.

        Example:
            >>> _compute_wind_component(15.0, 229.0, 49)
            # wind FROM SW at Wrigley → blowing out toward RF → positive
        """
        # Convert degrees to radians
        wind_from_rad = math.radians(wind_dir_deg)
        hp_bearing_rad = math.radians(hp_bearing)

        # Wind vector direction (where wind is going, not coming from)
        wind_to_rad = wind_from_rad + math.pi

        # Project wind vector onto HP→CF axis
        # cos(angle) > 0 = blowing out, < 0 = blowing in
        angle_diff = wind_to_rad - hp_bearing_rad
        component = wind_speed_mph * math.cos(angle_diff)

        return round(component, 3)
